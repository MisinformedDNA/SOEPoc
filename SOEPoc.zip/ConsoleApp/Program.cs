﻿// Copyright (c) Land O'Lakes. All rights reserved.

var types = typeof(SharedKernel.ValueObjects.OrderQuantityUnit).Assembly.DefinedTypes;
